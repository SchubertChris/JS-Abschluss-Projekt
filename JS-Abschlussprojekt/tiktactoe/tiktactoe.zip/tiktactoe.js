// Variablen
const player1 = '<i class="fa-solid fa-x"></i>'; // Symbol für Spieler 1
const player2 = '<i class="fa-regular fa-circle"></i>'; // Symbol für Spieler 2
let activePlayer = player1; // Startspieler
let boardState = Array(9).fill(null); // Spielfeldstatus: Array mit 9 Feldern (null = leer)
const winningCombinations = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];
const cells = document.querySelectorAll('.cell');
const display = document.querySelector('.display'); // Gewinneranzeige

// Funktionen

// Spiel starten
function startGame() {
  boardState.fill(null); // Spielfeld zurücksetzen
  activePlayer = player1; // Spieler 1 beginnt
  cells.forEach((cell, index) => {
    cell.innerHTML = ''; // Zellen leeren
    cell.classList.remove('filled'); // Entferne Füllstatus
    cell.setAttribute('data-hover-symbol', activePlayer === player1 ? 'X' : 'O'); // Hover-Symbol
    cell.addEventListener('click', () => handleClick(cell, index), { once: true }); // Einmaliger Klick
  });
  display.textContent = ''; // Gewinneranzeige leeren
}

// Klick-Handler
function handleClick(cell, index) {
  // Symbol setzen und Status aktualisieren
  cell.innerHTML = activePlayer;
  cell.classList.add('filled');
  boardState[index] = activePlayer;

  // Gewinn prüfen
  if (checkWin(activePlayer)) {
    displayWinner(activePlayer === player1 ? 'Player 1' : 'Player 2');
    return;
  }

  // Unentschieden prüfen
  if (boardState.every(cell => cell !== null)) {
    displayWinner('Nobody (Draw)');
    return;
  }

  // Spieler wechseln
  activePlayer = activePlayer === player1 ? player2 : player1;
  updateHoverSymbols();
}

// Hover-Symbole aktualisieren
function updateHoverSymbols() {
  cells.forEach((cell, index) => {
    if (!cell.classList.contains('filled')) {
      cell.setAttribute('data-hover-symbol', activePlayer === player1 ? 'X' : 'O');
    }
  });
}

// Gewinnprüfung
function checkWin(player) {
  return winningCombinations.some(combination => {
    return combination.every(index => boardState[index] === player);
  });
}

// Gewinner anzeigen
function displayWinner(winner) {
  display.textContent = `${winner} wins!`;
  cells.forEach(cell => cell.removeEventListener('click', handleClick)); // Alle Klicks deaktivieren
}

// Spiel initial starten
startGame();
