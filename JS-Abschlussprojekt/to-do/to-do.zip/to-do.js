const Eingabe = document.getElementById('eingabe'); // Eingabefeld holen
const Display = document.getElementById('display'); // Display holen

function addTask() {
    const task = Eingabe.value; // Wert aus Eingabefeld holen
    if (task) {
        // Li-Element erstellen, wenn task nicht leer ist
        const li = document.createElement('li');
        li.textContent = task;

        // "Erledigt"-Button erstellen
        const erledigtButton = document.createElement('button');
        erledigtButton.textContent = '👌'; // Text oder Icon für Button
        erledigtButton.classList.add('erledigt-button'); // Klasse hinzufügen
        erledigtButton.addEventListener('click', function () {
            li.classList.toggle('erledigt'); // Klasse 'erledigt' für durchgestrichen hinzufügen/entfernen
        });

        // Button in das Li-Element einfügen
        li.appendChild(erledigtButton);

        // Aufgabe zur Anzeige hinzufügen
        Display.appendChild(li);

        // Eingabefeld zurücksetzen
        Eingabe.value = '';
    }
}

// Event Listener für Enter-Taste
Eingabe.addEventListener('keyup', (event) => {
    if (event.key === 'Enter') { // Prüfen, ob Enter gedrückt wurde
        addTask(); // Aufgabe hinzufügen
    }
});
